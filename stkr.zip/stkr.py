from os import environ, execle, path, remove
import sys
#xfrom dotenv import load_dotenv, find_dotenv
from datetime import datetime
import time
import os
from PIL import Image
import math
from telegram import *
from telegram.ext import *
import logging
import random
from random import randint as rain
from moviepy.editor import *
#load_dotenv(find_dotenv())


from stkr_util import sendinfo

#ADMIN_LIST = os.getenv("ADMIN_LIST")
TELEGRAM_TOKEN = "5303865333:AAGfJuFb4mr7OGvpKp4WWpx-lOuJhJxziWQ"

#TELEGRAM_TOKEN = "5214279030:AAGl8vB850XGdjAkTCqZxsfoWHNIYubx46E"




emojiss = ["🌚", "😎", "😃", "😁", "😅", "🤗", "😇", "👀", "❤️", "👌", "👀", "🌈",
           "😐", "🤨", "😒", "😱", "🤣", "👌", "😆", "😍", "🧐", "😑"]


def restart(update, context):
    message = update.message
    if message.sender_chat:
        user_id = message.sender_chat.id
    else:
        user_id = message.from_user.id
    if int(user_id) == 1602293216:
        ht = message.reply_text(f"ʀᴇsᴛᴀʀᴛed")
        mid = ht.message_id
        chat_id = message.chat.id
        with open("re.txt", "w+") as rd:
            rd.write(f"{chat_id}_{mid}")
        args = [sys.executable, "stkr.py"]
        execle(sys.executable, *args, environ)
        exit()
        return





def clipinfo(vid):
     clip = VideoFileClip(vid)
     clip1 = clip.subclip(0, 10)
     width = None
     height = None
     try:
         width = clip1.w
         height = clip1.v
     finally:
         return width, height
 



def logs(update, context):
    if update.message.from_user:
        if update.message.from_user.id == 1602293216:
            update.message.reply_document(document=open("log.txt", "rb"))


def ping(update, context):
    if update.message.from_user:
        if update.message.from_user.id == 1602293216:
            chat_id = update.message.chat_id
            m = update.message
            start = time.time()
            replymsg = m.reply_text("....", quote=True)
            delta_ping = time.time() - start
            m.reply_text(
                f"**Pong!**\n{delta_ping * 1000:.3f} ms", parse_mode="markdown")
            replymsg.delete()
            return


# ported/kanged + modded from https://github.com/skittles9823/kangbot


def start(update, context):
    update.message.reply_text("""
/kang <emoji>: to kang sticker to your pack
/delsticker: reply to a sticker to delete from your sticker pack
/mypacks : Get all your sticker packs
/packkang : kang all stickers of a pack
/packkang x-y : kang from-to stickers from a pack
(eg:- `/packkang 6-9`)

""", parse_mode="markdown")



def nuke(update, context):
   if update.message.from_user:
        if update.message.from_user.id == 1602293216:
            os.system("rm -rf *.mkv *.tgs *.png *.jpg *.webm *.mp4")
            update.message.reply_text("Done !")
   
def broadcast(update, context):
    return 
    users = [6265593475, 5817544006, 4587101040, 7865256065, 6805742828]
    for user in users:
        try:
            context.bot.send_message(chat_id=user, text="Sorry for the inconvenience, you can kang now ...")
            print(user, "success ")
        except Exception as e:
            print(e)












def kang(update, context):
    user_id = None
    if update.message.from_user:
        user_id = str(update.message.from_user.id)
        print(f"kang {user_id}, {update.message.from_user.first_name}")
    else:
        update.message.reply_text("Message as a user !")
        return
    if user_id:
        context.bot.sendChatAction(update.message.chat_id, 'choose_sticker')
        msg = update.message
        user = update.message.from_user
        chat_id = update.message.chat_id
        if os.path.isfile(f"{user_id}.png"):
            try:
                os.remove("{user_id}.png")
            except:
                pass
        if os.path.isfile("{user_id}.tgs"):
            try:
                os.remove("{user_id}.tgs")
            except:
                pass
        if update.message.reply_to_message:
            if msg.reply_to_message.sticker:
                if msg.reply_to_message.sticker.is_animated == True:
                    file_id = msg.reply_to_message.sticker.file_id
                    kangani(update, context)
                elif msg.reply_to_message.sticker.is_video == True:
                    file_id = msg.reply_to_message.sticker.file_id
                    kangwebm(update, context)
                else:
                    kangMyAss(update, context, chat_id)
            elif msg.reply_to_message.sticker or msg.reply_to_message.photo:
                kangMyAss(update, context, chat_id)
            elif msg.reply_to_message.video:
                    file_id = msg.reply_to_message.video.file_id
                    kangwebm(update, context)
            elif msg.reply_to_message.document:
                 #   file_id = msg.reply_to_message.video.file_id
                    kangwebm(update, context)
        else:
            packs = "Please reply to a sticker or image to kang it!\nBtw here are your packs:\n"
            packname = "kang_" + str(user_id) + "_by_" + \
                str(context.bot.username)
            try:
                stickerset = context.bot.get_sticker_set(packname)
                packnum = 1
            except:
                packnum = 0
               # update.message.reply_text("Please reply to a sticker, or image to kang it!")
            if packnum > 0:
                onlypack = 0
                while onlypack == 0:
                    try:
                        stickerset = context.bot.get_sticker_set(packname)
                        packs += f"[pack{packnum}](t.me/addstickers/{packname})\n"

                    except:
                        onlypack = 1

                    packnum += 1
                    packname = "kang_" + \
                        str(packnum - 1) + "_" + str(user_id) + \
                        "_by_"+str(context.bot.username)
            else:
                packs += f"[pack](t.me/addstickers/{packname})"
            update.message.reply_text(parse_mode='markdown',
                                      text=packs)


def mypacks(update, context):
    user_id = None
    if update.message.from_user:
        user_id = str(update.message.from_user.id)
        user = update.message.from_user
    else:
        update.message.reply_text("Message as a user !")
        return
    packs = f"{update.message.from_user.first_name}'s sticker packs:\n"
    packs1 = ""
    packs2 = ""
    packname = "kang_" + str(user_id) + "_by_"+str(context.bot.username)
    try:
        stickerset = context.bot.get_sticker_set(packname)
        packnum = 1
    except:
        packnum = 0

    if packnum > 0:
        onlypack = 0
        while onlypack == 0:
            try:
                stickerset = context.bot.get_sticker_set(packname)
                packs += f"[pack{packnum}](t.me/addstickers/{packname})\n"

            except:
                onlypack = 1

            packnum += 1
            packname = "kang_" + \
                str(packnum - 1) + "_" + str(user_id) + \
                "_by_"+str(context.bot.username)

    packname = "kang_" + str(user.id) + "animated_by_" + \
        str(context.bot.username)
    try:
        stickerset = context.bot.get_sticker_set(packname)
        packnum = 1
    except:
        packnum = 0

    if packnum > 0:
        onlypack = 0
        packs1 += "Animatied packs:\n"
        while onlypack == 0:
            try:
                stickerset = context.bot.get_sticker_set(packname)
                packs1 += f"[pack{packnum}](t.me/addstickers/{packname})\n"

            except:
                onlypack = 1

            packnum += 1
            packname = "kang_" + \
                str(packnum) + "_" + str(user.id) + \
                "animated_by_"+str(context.bot.username)

    packname = "kang_" + str(user.id) + "video_by_"+str(context.bot.username)
    try:
        stickerset = context.bot.get_sticker_set(packname)
        packnum = 1
    except:
        packnum = 0

    if packnum > 0:
        onlypack = 0
        packs2 += "Video sticker pack:\n"
        while onlypack == 0:
            try:
                stickerset = context.bot.get_sticker_set(packname)
                packs2 += f"[pack{packnum}](t.me/addstickers/{packname})\n"

            except:
                onlypack = 1

            packnum += 1
            packname = "kang_" + \
                str(packnum) + "_" + str(user.id) + \
                "video_by_"+str(context.bot.username)

    update.message.reply_text(
        f"\n{packs}{packs1}{packs2}", parse_mode='markdown')


def kangMyAss(update, context, chat_id):
    context.bot.sendChatAction(update.message.chat_id, 'choose_sticker')
    msg = update.message
    user = update.message.from_user
    user_id = str(update.message.from_user.id)
    chat_id = chat_id
    packnum = 0
    packname = "kang_" + str(user.id) + "_by_"+str(context.bot.username)
    hm = update.message.reply_text(
        f"`Processing  ⏳ ...`", parse_mode='markdown')
    context.bot.sendChatAction(chat_id, 'choose_sticker')
    msg_id = f'{hm.message_id}'
    packname_found = 0
    max_stickers = 120
    while packname_found == 0:
        try:
            stickerset = context.bot.get_sticker_set(packname)
            if len(stickerset.stickers) >= max_stickers:
                packnum += 1
                packname = "kang_" + \
                    str(packnum) + "_" + str(user.id) + \
                    "_by_"+str(context.bot.username)
            else:
                packname_found = 1
        except Exception as e:
            if str(e) == "Stickerset_invalid":
                packname_found = 1
    idk = str(rain(0000000000, 9999999999))
    kangsticker = f"{idk}.png"
    if msg.reply_to_message:
        if msg.reply_to_message.sticker:
            file_id = msg.reply_to_message.sticker.file_id
        elif msg.reply_to_message.photo:
            file_id = msg.reply_to_message.photo[1].file_id
        elif msg.reply_to_message.document:
            file_id = msg.reply_to_message.document.file_id
        else:
            msg.reply_text("I can't kang that")
        kang_file = context.bot.get_file(file_id)
        kang_file.download(f'{idk}.png')
        try:
            sticker_emoji = msg.text.split(' ')[1]
        except:
            try:
                sticker_emoji = msg.reply_to_message.sticker.emoji
            except:
                sticker_emoji = random.choice(emojiss)
        try:
            im = Image.open(f'{idk}.png')
            maxsize = (512, 512)
            if (im.width and im.height) < 512:
                size1 = im.width
                size2 = im.height
                if im.width > im.height:
                    scale = 512 / size1
                    size1new = 512
                    size2new = size2 * scale
                else:
                    scale = 512 / size2
                    size1new = size1 * scale
                    size2new = 512
                size1new = math.floor(size1new)
                size2new = math.floor(size2new)
                sizenew = (size1new, size2new)
                im = im.resize(sizenew)
            else:
                im.thumbnail(maxsize)
          #  if not msg.reply_to_message.sticker:
            im.save(f'{idk}.png')
            context.bot.add_sticker_to_set(user_id=user.id,
                                           name=packname,
                                           png_sticker=open(
                                               f'{idk}.png', 'rb'),
                                           emojis=sticker_emoji)
            hm1 = context.bot.editMessageText(chat_id=chat_id,
                                              message_id=msg_id,
                                              parse_mode='markdown',
                                              text=f"*Sticker successfully added to*: [pack](t.me/addstickers/{packname}) \n*Emoji is*: {sticker_emoji}")
        except OSError as e:
            hm1 = context.bot.editMessageText(chat_id=chat_id,
                                              message_id=msg_id,
                                              parse_mode='markdown',
                                              text=f"I can kang only images")
            print(e)
            return
        except Exception as e:
            if str(e) == "Stickerset_invalid":
                hm2 = context.bot.editMessageText(chat_id=chat_id,
                                                  message_id=msg_id,
                                                  parse_mode='markdown',
                                                  text=f"`Brewing a new pack ...`")
                context.bot.sendChatAction(chat_id, 'choose_sticker')
                makekang_internal(msg, user, open(f'{idk}.png', 'rb'),
                                  sticker_emoji, context, packname, packnum, chat_id, msg_id, idk)
            elif str(e) == "Sticker_png_dimensions":
                im.save(f'{idk}.png')
                context.bot.add_sticker_to_set(user_id=user.id,
                                               name=packname,
                                               png_sticker=open(
                                                   f'{idk}.png', 'rb'),
                                               emojis=sticker_emoji)
                hm1 = context.bot.editMessageText(chat_id=chat_id,
                                                  message_id=msg_id,
                                                  parse_mode='markdown',
                                                  text=f"*Sticker successfully added to*: [pack](t.me/addstickers/%s)" % packname + "\n"
                                                  "*Emoji is:*" + " " + sticker_emoji)
            elif str(e) == "Stickers_too_much":
                msg.reply_text("Max pack size reached")
            elif str(e) == "Internal Server Error: sticker set not found (500)":
                hm1 = context.bot.editMessageText(chat_id=chat_id,
                                                  message_id=msg_id,
                                                  parse_mode='markdown',
                                                  text=f"*Sticker successfully added to*: [pack](t.me/addstickers/%s)" % packname + "\n"
                                                  "*Emoji is:*" + " " + sticker_emoji)

            elif str(e) == "Invalid sticker emojis":
                sticker_emoji = random.choice(emojiss)
                context.bot.add_sticker_to_set(user_id=user.id,
                                               name=packname,
                                               png_sticker=open(
                                                   f'{idk}.png', 'rb'),
                                               emojis=sticker_emoji)
                hm1 = context.bot.editMessageText(chat_id=chat_id,
                                                  message_id=msg_id,
                                                  parse_mode='markdown',
                                                  text=f"*Sticker successfully added to*: [pack](t.me/addstickers/%s)" % packname + "\n"
                                                  "*Emoji is:*" + " " + sticker_emoji)
            else:
                print("tg error", str(e))
        except Exception as e:
            print("last exp", e)
    if os.path.isfile(f"{idk}.png"):
        os.remove(f"{idk}.png")


def makekang_internal(msg, user, png_sticker, emoji, context, packname, packnum, chat_id, msg_id, idk):
    name = user.first_name
    name = name[:50]
    user_id = str(user.id)
    success = None
    try:
        extra_version = ""
        if packnum > 0:
            extra_version = " " + str(packnum)
        success = context.bot.create_new_sticker_set(user.id, packname, f"{name}'s kang pack" + extra_version,
                                                     png_sticker=png_sticker,
                                                     emojis=emoji)
    except Exception as e:
        if str(e) == "Sticker set name is already occupied":
            hm1 = context.bot.editMessageText(chat_id=chat_id,
                                              message_id=msg_id,
                                              parse_mode='markdown',
                                              text="Your pack can be found [here](t.me/addstickers/%s)" % packname)

        elif str(e) == "Peer_id_invalid":
            hm1 = context.bot.editMessageText(chat_id=chat_id,
                                              message_id=msg_id,
                                              parse_mode='markdown',
                                              text="Contact me in PM first.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                                                  text="Start", url=f"t.me/{context.bot.username}?start")]]))
            return
        elif str(e) == "Internal Server Error: created sticker set not found (500)":
            hm1 = context.bot.editMessageText(chat_id=chat_id,
                                              message_id=msg_id,
                                              parse_mode='markdown',
                                              text="*Sticker pack successfully created.* `Get it`  [here](t.me/addstickers/%s)" % packname)
        elif str(e) == "Invalid sticker emojis":
            sticker_emoji = random.choice(emojiss)
            try:
                context.bot.add_sticker_to_set(user_id=user.id,
                                               name=packname,
                                               png_sticker=open(
                                                   f'{idk}.png', 'rb'),
                                               emojis=sticker_emoji)
            except Exception as e:
                if str(e) == "Stickerset_invalid":
                    success = context.bot.create_new_sticker_set(user.id, packname, f"{name}'s kang pack" + extra_version,
                                                                 png_sticker=open(
                                                                     f'{idk}.png', 'rb'),
                                                                 emojis=sticker_emoji)
            hm1 = context.bot.editMessageText(chat_id=chat_id,
                                              message_id=msg_id,
                                              parse_mode='markdown',
                                              text="*Sticker pack successfully created.* `Get it`  [here](t.me/addstickers/%s)" % packname)
        elif str(e) == "Sticker_png_dimensions":
            im = Image.open(f'{idk}.png')
            maxsize = (512, 512)
            if (im.width and im.height) < 512:
                size1 = im.width
                size2 = im.height
                if im.width > im.height:
                    scale = 512 / size1
                    size1new = 512
                    size2new = size2 * scale
                else:
                    scale = 512 / size2
                    size1new = size1 * scale
                    size2new = 512
                size1new = math.floor(size1new)
                size2new = math.floor(size2new)
                sizenew = (size1new, size2new)
                im = im.resize(sizenew)
            else:
                im.thumbnail(maxsize)
            im.save(f'{idk}.png')
            success = context.bot.create_new_sticker_set(user.id, packname, f"{name}'s kang pack" + extra_version,
                                                         png_sticker=png_sticker,
                                                         emojis=emoji)
        else:
            print("make pack", e)
    if success:
        hm1 = context.bot.editMessageText(chat_id=chat_id,
                                          message_id=msg_id,
                                          parse_mode='markdown',
                                          text=f"*Sticker pack successfully created.* ` Get it`  [here](t.me/addstickers/%s)" % packname)
    else:
        hm1 = context.bot.editMessageText(chat_id=chat_id,
                                          message_id=msg_id,
                                          parse_mode='markdown',
                                              text="`Failed to create sticker pack. Possibly due to blek mejik.`")

    #######


def kangani(update, context):
    context.bot.sendChatAction(update.message.chat_id, 'choose_sticker')
    msg = update.message
    user = update.message.from_user
    name = user.first_name
    chat_id = update.message.chat_id
    user_id = str(update.message.from_user.id)
    name = name[:50]
    packnum = 0
    packname = "kang_" + str(user.id) + "animated_by_" + \
        str(context.bot.username)
    hm = update.message.reply_text(
        f"`Processing ⏳ ...`", parse_mode='markdown')
    context.bot.sendChatAction(chat_id, 'choose_sticker')
    packname_found = 0
    max_stickers = 120
    while packname_found == 0:
        try:
            stickerset = context.bot.get_sticker_set(packname)
            if len(stickerset.stickers) >= max_stickers:
                packnum += 1
                packname = "kang_" + \
                    str(packnum) + "_" + str(user.id) + \
                    "animated_by_"+str(context.bot.username)
            else:
                packname_found = 1
        except Exception as e:
            if str(e) == "Stickerset_invalid":
                packname_found = 1
    idk = str(rain(0000000000, 9999999999))
    kangsticker = f"{idk}.tgs"
    if msg.reply_to_message:
        if msg.reply_to_message.sticker:
            file_id = msg.reply_to_message.sticker.file_id
        else:
            msg.reply_text("I can't kang that")
        kang_file = context.bot.get_file(file_id)
        kang_file.download(f'{idk}.tgs')
        try:
            sticker_emoji = msg.text.split(' ')[1]
        except:
            try:
                sticker_emoji = msg.reply_to_message.sticker.emoji
            except:
                sticker_emoji = random.choice(emojiss)
        try:
            hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                              message_id=hm.message_id,
                                              parse_mode='markdown',
                                              text=f"`With emoji` '{sticker_emoji}'")
            context.bot.sendChatAction(chat_id, 'choose_sticker')
            context.bot.add_sticker_to_set(user_id=user.id,
                                           name=packname,
                                           tgs_sticker=open(
                                               f'{idk}.tgs', 'rb'),
                                           emojis=sticker_emoji)
            hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                              message_id=hm1.message_id,
                                              parse_mode='markdown',
                                              text=f"*Sticker successfully added to*: [pack](t.me/addstickers/{packname}) \n*Emoji is*: {sticker_emoji}")
        except Exception as e:
            if str(e) == "Stickerset_invalid":
                hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                                  message_id=hm.message_id,
                                                  parse_mode='markdown',
                                                  text="`Brewing a new pack ...`")
                context.bot.sendChatAction(chat_id, 'choose_sticker')
                try:
                    extra_version = ""
                    if packnum > 0:
                        extra_version = " " + str(packnum)
                    success = context.bot.create_new_sticker_set(user.id, packname, f"{name}'s animated kang pack" + extra_version,
                                                                 tgs_sticker=open(
                                                                     f'{idk}.tgs', 'rb'),
                                                                 emojis=random.choice(emojiss))
                except Exception as e:

                    if str(e) == "Sticker set name is already occupied":
                        msg.reply_text(
                            "Your pack can be found [here](t.me/addstickers/%s)" % packname)
                    elif str(e) == "Peer_id_invalid":
                        msg.reply_text("Contact me in PM first.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                            text="Start", url=f"t.me/{context.bot.username}")]]))
                    elif str(e) == "Internal Server Error: created sticker set not found (500)":
                        hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                                          message_id=hm.message_id,
                                                          parse_mode='markdown',
                                                          text="*Sticker pack successfully created.* `Get it`  [here](t.me/addstickers/%s)" % packname)
                if success:
                    hm2 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                                      message_id=hm1.message_id,
                                                      parse_mode='markdown',
                                                      text=f"*Sticker pack successfully created.* `Get it`  [here](t.me/addstickers/%s)" % packname)
                else:
                    hm2 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                                      message_id=hm1.message_id,
                                                      parse_mode='markdown',
                                                      text="Failed to create sticker pack. Possibly due to blek mejik.")
                                                      
            elif str(e) == "Sticker set name is already occupied":
                        msg.reply_text(
                            "Your pack can be found [here](t.me/addstickers/%s)" % packname)
            elif str(e) == "Peer_id_invalid":
                        msg.reply_text("Contact me in PM first.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                            text="Start", url=f"t.me/{context.bot.username}")]]))
            elif str(e) == "Internal Server Error: created sticker set not found (500)":
                        hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                                          message_id=hm.message_id,
                                                          parse_mode='markdown',
                                                          text="*Sticker pack successfully created.* `Get it`  [here](t.me/addstickers/%s)" % packname)
                                                                                                             
        if os.path.isfile(f"{idk}.tgs"):
                    os.remove(f"{idk}.tgs")


def kangwebm(update, context):
    context.bot.sendChatAction(update.message.chat_id, 'choose_sticker')
    msg = update.message
    user = update.message.from_user
    name = user.first_name
    chat_id = update.message.chat_id
    user_id = str(update.message.from_user.id)
    name = name[:50]
    packnum = 0
    packname = "kang_" + str(user.id) + "video_by_"+str(context.bot.username)
    hm = update.message.reply_text(
        f"`Processing ⏳ ...`", parse_mode='markdown')
    context.bot.sendChatAction(chat_id, 'choose_sticker')
    packname_found = 0
    max_stickers = 50
    idk = str(rain(0000000000, 9999999999))
    while packname_found == 0:
        try:
            stickerset = context.bot.get_sticker_set(packname)
            if len(stickerset.stickers) >= max_stickers:
                packnum += 1
                packname = "kang_" + \
                    str(packnum) + "_" + str(user.id) + \
                    "video_by_"+str(context.bot.username)
            else:
                packname_found = 1
        except Exception as e:
            if str(e) == "Stickerset_invalid":
                packname_found = 1
   # rint(msg.reply_to_message.document)
    if msg.reply_to_message.video or msg.reply_to_message.document:      
      
       if msg.reply_to_message.video:
          true_size = int(msg.reply_to_message.video .file_size) / 1024
          if int(true_size) > 3100:
               hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                              message_id=hm.message_id,
                                              parse_mode='markdown',
                                              text=f"`File size is too big !`")
               return
          
          kang_file = context.bot.get_file(msg.reply_to_message.video.file_id)
          dw =  kang_file.download(f'{idk}.mkv')
         
       elif msg.reply_to_message.document:
          
           true_size = int(msg.reply_to_message.document.file_size) / 1024
           if int(true_size) > 3100:
               hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                              message_id=hm.message_id,
                                              parse_mode='markdown',
                                              text=f"`File size is too big !`")
               return
           get_doc_info = msg.reply_to_message.document.mime_type
        
           if get_doc_info == "video/mp4":
                 kang_file = context.bot.get_file(msg.reply_to_message.document.file_id)
                 dw = kang_file.download(f'{idk}.mkv')
              
       try:
          hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                              message_id=hm.message_id,
                                              parse_mode='markdown',
                                              text=f"`This can take couple of time (10-20 seconds) according to the video size, so please keep patience!\nProcessing ....`\nTip: For best results send the video in document format.")
       finally:
          v_h, v_w, v_d = 512, 512, "2.9"
          get_info = msg.reply_to_message.video
          print(get_info)
          if get_info:
            v_w = get_info.width
            v_h = get_info.height
          else:
            try:
                vid_clip = sendinfo(f"{idk}.mkv")
         
                v_w = vid_clip[0]
                v_h = vid_clip[1]
                v_d = vid_clip[2]
                if int(v_d) > 3:
                   v_d = "2.9"
            except Exception as e:
               print(e)
          if int(float(v_d)) >= 3:
              v_d = "2.9"

          print(v_d)
          if v_h and v_w:
            if v_w > v_h:
               print(f"1st {v_d}")
               os.system(f"webm -t {v_d} -vw 512 -l 0.028 -an -i {idk}.mkv")
            elif v_w < v_h:
               print(f"2nd {v_d}")
               os.system(f"webm -t {v_d} -vh 512 -l 0.028 -an -i {idk}.mkv")
            elif v_w == v_h:
               print(f"3rd {v_d}")
               os.system(f"webm -t {v_d} -vh 512 -l 0.028 -an -i {idk}.mkv")
   
            os.system(f"mv -f {idk}*.webm {idk}.webm")
          else:
             print("did not got the weidth and height")
             print(f"4th {v_d}")
             os.system(f"webm -t {v_d} -vh {v_h} -{v_w} 512 -l 0.028 -an -i {idk}.mkv")   
             os.system(f"mv -f {idk}*.webm {idk}.webm")
             mesq = "There is error in finding the dimensions/info of video, please send it in video or document (not in Gif)"
             if not os.path.exists(f"{idk}.webm"):
                  hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                                message_id = hm.message_id,
 text = mesq)
                  return
    elif msg.reply_to_message.sticker:
       kang_file = context.bot.get_file(msg.reply_to_message.sticker.file_id)
       kang_file.download(f'{idk}.webm')
    else:
        hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                              message_id=hm.message_id,
                                              parse_mode='markdown',
                                              text=f"`Error with the file!\n send as document or video!`")
        return 

    if msg.reply_to_message:
        if msg.reply_to_message.sticker:
            file_id = msg.reply_to_message.sticker.file_id
        elif msg.reply_to_message.video or msg.reply_to_message.document:
            pass
        else:
            msg.reply_text("I can't kang that")
            return
        try:
            sticker_emoji = msg.text.split(' ')[1]
        except:
            try:
                sticker_emoji = msg.reply_to_message.sticker.emoji
            except Exception as e:

                sticker_emoji = random.choice(emojiss)
        try:
            hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                              message_id=hm.message_id,
                                              parse_mode='markdown',
                                              text=f"`With emoji` '{sticker_emoji}'")
            context.bot.sendChatAction(chat_id, 'choose_sticker')
            context.bot.add_sticker_to_set(user_id=user.id,
                                           name=packname,
                                           webm_sticker=open(
                                               f'{idk}.webm', 'rb'),
                                           emojis=sticker_emoji)
            hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                              message_id=hm1.message_id,
                                              parse_mode='markdown',
                                              text=f"*Sticker successfully added to*: [pack](t.me/addstickers/{packname}) \n*Emoji is*: {sticker_emoji}")
        except Exception as e:
            print("video kang error", e)
            if str(e) == "Stickerset_invalid" or str(e) == "Stickers_too_much":
                hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                                  message_id=hm.message_id,
                                                  parse_mode='markdown',
                                                  text="`Brewing a new pack ...`")
                context.bot.sendChatAction(chat_id, 'choose_sticker')
                try:
                    extra_version = ""
                    if packnum > 0:
                        extra_version = " " + str(packnum)
                    success = context.bot.create_new_sticker_set(user.id, packname, f"{name}'s video sticker kang pack" + extra_version,
                                                                 webm_sticker=open(
                                                                     f'{idk}.webm', 'rb'),
                                                                 emojis=random.choice(emojiss))
                except Exception as e:
                    print(e)
                    success = None
                    if str(e) == "Sticker set name is already occupied":
                        msg.reply_text(
                            "Your pack can be found [here](t.me/addstickers/%s)" % packname)
                    elif str(e) == "Peer_id_invalid":
                        msg.reply_text("Contact me in PM first.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                            text="Start", url=f"t.me/{context.bot.username}")]]))
                    elif str(e) == "Internal Server Error: created sticker set not found (500)":
                        hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                                          message_id=hm.message_id,
                                                          parse_mode='markdown',
                                                          text="*Sticker pack successfully created.* `Get it`  [here](t.me/addstickers/%s)" % packname)
                if success:
                    hm2 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                                      message_id=hm1.message_id,
                                                      parse_mode='markdown',
                                                      text=f"*Sticker pack successfully created.* `Get it`  [here](t.me/addstickers/%s)" % packname)
                else:
                    hm2 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                                      message_id=hm1.message_id,
                                                      parse_mode='markdown',
                                                      text="Failed to create sticker pack. Possibly due to blek mejik.")

            elif str(e) == "Sticker_video_nowebm":
                context.bot.editMessageText(chat_id=update.message.chat_id,
                                            message_id=hm.message_id,
                                            parse_mode='markdown',
                                            text="An unexpected error arrived, try again !")


            elif str(e) == "Sticker set name is already occupied":
                        msg.reply_text(
                            "Your pack can be found [here](t.me/addstickers/%s)" % packname)
            elif str(e) == "Peer_id_invalid":
                        msg.reply_text("Contact me in PM first.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                            text="Start", url=f"t.me/{context.bot.username}")]]))
            elif str(e) == "Internal Server Error: created sticker set not found (500)":
                        hm1 = context.bot.editMessageText(chat_id=update.message.chat_id,
                                                          message_id=hm.message_id,
                                                          parse_mode='markdown',
                                                          text="*Sticker pack successfully created.* `Get it`  [here](t.me/addstickers/%s)" % packname)
                                                                                                             
   
        if os.path.isfile(f"{idk}.webm"):
                os.remove(f"{idk}.webm")


def delsticker(update, context):
    user_id = None
    if update.message.from_user:
        user_id = str(update.message.from_user.id)
        print(f"del {user_id}, {update.message.from_user.first_name}")
    else:
        update.message.reply_text("Message as a user !")
        return
    if user_id:
        if update.message.reply_to_message and update.message.reply_to_message.sticker:
            stickerset = update.message.reply_to_message.sticker.set_name
        else:
            update.message.reply_text(
                "Sticker to delete not found !", quote=True)
            return
        if (str(user_id) in str(stickerset)) or user_id == "1602293216":
            context.bot.sendChatAction(
                update.message.chat_id, 'choose_sticker')
            try:
                context.bot.deleteStickerFromSet(
                    sticker=update.message.reply_to_message.sticker.file_id)
                update.message.reply_text(
                    "Successfully deleted the sticker from your pack", quote=True)
            except Exception as e:
                if str(e) == "'NoneType' object has no attribute 'sticker'":
                    update.message.reply_text(
                        "Sticker to delete not found !", quote=True)
                elif str(e) == "Stickerset_not_modified":
                    update.message.reply_text(
                        "Sticker to delete not found !", quote=True)
                else:
                    update.message.reply_text(str(e))
        else:
            update.message.reply_text(
                "This isn't your sticker pack !")
########## __kang_sticker(animated+normal)__ ########


def kangall(update, context):
    user_id = None
    chat_id = update.message.chat_id
    if update.message.from_user:
        user_id = str(update.message.from_user.id)        
    else:
        update.message.reply_text("Message as a user !")
        return
    if user_id:
        context.bot.sendChatAction(update.message.chat_id, 'choose_sticker')
        msg = update.message
        user = update.message.from_user
        chat_id = update.message.chat_id
        idk = str(rain(0000000000, 9999999999))
        os.system(f"mkdir -p {idk}x")
       # os.system(f"mkdir -p {user_id} && rm -rf {user_id}/*")
        context.bot.sendChatAction(update.message.chat_id, 'choose_sticker')
        one = update.message.reply_text("Trying to kang full pack ...")
        name = update.message.from_user.first_name
        print(f"kang {user_id}, {update.message.from_user.first_name}")
        try:
            logging.info(f"kang {user_id}, {update.message.from_user.first_name}")
        except:
            pass
    if msg.reply_to_message:
        if msg.reply_to_message.sticker and not msg.reply_to_message.sticker.is_animated and not msg.reply_to_message.sticker.is_video:
            mpackname = update.message.reply_to_message.sticker.set_name
            mstickerset = context.bot.get_sticker_set(mpackname).stickers
            sticker_num = len(mstickerset)
            k = 1
            packname = "kang_" + str(user_id) + "_by_" + \
                str(context.bot.username)
            packname_found = 0
            max_stickers = 120
            packnum = 0
            lgbt = None
            fs = 1
            ts = sticker_num
            if " " in str(msg.text):
                wwe = str(msg.text).split()[1]

                if "-" in wwe:
                    try:
                        fs = int(wwe.split("-")[0])
                        if not fs < 120 and not fs > 0:
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text=f"Sike!, that's the wrong number!")
                            return
                        ts = int(wwe.split("-")[1])
                        if not ts <= 120:
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text=f"Sike!, that's the wrong number!")
                            return
                        if fs > ts:
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text=f"Wrong info !")
                            return
                    except:
                        context.bot.editMessageText(chat_id=chat_id,
                                                    message_id=one.message_id,
                                                    parse_mode='markdown',
                                                    text=f"Sike!, that's the wrong number!")
                        return
                elif wwe.isdigit():
                    try:
                        fs = int(wwe)
                        ts = sticker_num
                        if not fs >= ts and not fs > 0:
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text=f"Sike!, that's the wrong number!")
                            return
                    except:
                        context.bot.editMessageText(chat_id=chat_id,
                                                    message_id=one.message_id,
                                                    parse_mode='markdown',
                                                    text=f"Sike!, that's the wrong number!")
                        return
        ######
            packname_found = 0
            max_stickers = 120
            while packname_found == 0:
                try:
                    stickerset = context.bot.get_sticker_set(packname)
                    if len(stickerset.stickers) >= max_stickers:
                        packnum += 1
                        packname = "kang_" + \
                            str(packnum) + "_" + str(user.id) + \
                            "_by_"+str(context.bot.username)
                    else:
                        packname_found = 1
                except Exception as e:
                    if str(e) == "Stickerset_invalid":
                        packname_found = 1

            for i in mstickerset:
                if k > ts:
                    break
                try:
                    sticker_emoji = i.emoji
                except:
                    sticker_emoji = random.choice(emojiss)
                if (fs > 1 and fs <= k) or (fs == 1):
                    try:
                        two = context.bot.editMessageText(chat_id=chat_id,
                                                          message_id=one.message_id,
                                                          parse_mode='markdown',
                                                          text=f"Kanging {k}/{sticker_num}\nWith emoji '{sticker_emoji}'")
                    except:
                        pass
                    kang_file = context.bot.get_file(i.file_id)
                    kang_file.download(f'{idk}x/{k}.png')

                    try:
                        context.bot.add_sticker_to_set(user_id=user.id,
                                                       name=packname,
                                                       png_sticker=open(
                                                           f'{idk}x/{k}.png', 'rb'),
                                                       emojis=sticker_emoji)

                    except Exception as e:                   
                        if str(e) == "Stickerset_invalid":                            
                            extra_version = ""
                            if packnum > 0:
                                extra_version = " " + str(packnum)
                            try:
                                context.bot.create_new_sticker_set(user.id, packname, f"{name}'s kang pack" + extra_version,
                                                               png_sticker=open(
                                                                   f'{idk}x/{k}.png', 'rb'),
                                                               emojis=sticker_emoji)
                            except Exception as e:
                                if str(e) == "Peer_id_invalid":
                                      context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text="Contact me in PM first.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                                                            text="Start", url=f"t.me/{context.bot.username}?start")]]))
                                      lgbt = True
                                      break
                                
                        elif str(e) == "Stickers_too_much" or e == "Stickerkang_stickers_too_much":
                            packnum += 1
                            extra_version = " " + str(packnum)
                            packname = "kang_" + \
                                str(packnum) + "_" + str(user.id) + \
                                "_by_"+str(context.bot.username)
                            try:
                                context.bot.create_new_sticker_set(user.id, packname, f"{name}'s kang pack" + extra_version,
                                                                   png_sticker=open(
                                                                       f'{idk}x/{k}.png', 'rb'),
                                                                   emojis=sticker_emoji)
                            except:
                                context.bot.add_sticker_to_set(user_id=user.id,
                                                               name=packname,
                                                               png_sticker=open(
                                                                   f'{idk}x/{k}.png', 'rb'),
                                                               emojis=sticker_emoji)
                        elif str(e) == "Peer_id_invalid":
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                     text="Contact me in PM first.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                                                            text="Start", url=f"t.me/{context.bot.username}?start")]]))
                            lgbt = True
                            break
                        else:
                            print("packkang error(sticker)\n", e)
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text=f"Error !\nTry `/packkang {k}` to continue kang.")
                            lgbt = True
                            break

                k += 1

            if lgbt:
                return
            else:
                context.bot.editMessageText(chat_id=chat_id,
                                            message_id=one.message_id,
                                            parse_mode='markdown',
                                            text=f"Done !\nPack: [Sticker pack](t.me/addstickers/{packname}")
            # animated
        elif msg.reply_to_message.sticker.is_animated:
            mpackname = update.message.reply_to_message.sticker.set_name
            mstickerset = context.bot.get_sticker_set(mpackname).stickers
            sticker_num = len(mstickerset)
            k = 1
            lgbt = None
            packname = "kang_" + str(user_id) + \
                "animated_by_"+str(context.bot.username)
            packname_found = 0
            max_stickers = 120
            packnum = 0
            fs = 1
            ts = sticker_num
            if " " in str(msg.text):
                wwe = str(msg.text).split()[1]

                if "-" in wwe:
                    try:
                        fs = int(wwe.split("-")[0])
                        if not fs < 120 and not fs > 0:
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text=f"Sike!, that's the wrong number!")
                            return
                        ts = int(wwe.split("-")[1])
                        if not ts <= 120:
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text=f"Sike!, that's the wrong number!")
                            return
                        if fs > ts:
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text=f"Wrong info !")
                            return
                    except:
                        context.bot.editMessageText(chat_id=chat_id,
                                                    message_id=one.message_id,
                                                    parse_mode='markdown',
                                                    text=f"Sike!, that's the wrong number!")
                        return
                elif wwe.isdigit():
                    try:
                        fs = int(wwe)
                        ts = sticker_num
                        if not fs >= ts and not fs > 0:
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text=f"Sike!, that's the wrong number!")
                            return
                    except:
                        context.bot.editMessageText(chat_id=chat_id,
                                                    message_id=one.message_id,
                                                    parse_mode='markdown',
                                                    text=f"Sike!, that's the wrong number!")
                        return
        ######
            packname_found = 0
            max_stickers = 120
            while packname_found == 0:
                try:
                    stickerset = context.bot.get_sticker_set(packname)
                    if len(stickerset.stickers) >= max_stickers:
                        packnum += 1
                        packname = "kang_" + \
                            str(packnum) + "_" + str(user.id) + \
                            "animated_by_"+str(context.bot.username)
                    else:
                        packname_found = 1
                except Exception as e:
                    if str(e) == "Stickerset_invalid":
                        packname_found = 1
            for i in mstickerset:
                if k > ts:
                    break
                try:
                    sticker_emoji = i.emoji
                except:
                    sticker_emoji = random.choice(emojiss)
                if (fs > 1 and fs <= k) or (fs == 1):
                    try:
                        two = context.bot.editMessageText(chat_id=chat_id,
                                                          message_id=one.message_id,
                                                          parse_mode='markdown',
                                                          text=f"Kanging {k}/{sticker_num}\nWith emoji '{sticker_emoji}'")
                    except:
                        pass
                    kang_file = context.bot.get_file(i.file_id)
                    kang_file.download(f'{idk}x/{k}.tgs')

                    try:
                        context.bot.add_sticker_to_set(user_id=user.id,
                                                       name=packname,
                                                       tgs_sticker=open(
                                                           f'{idk}x/{k}.tgs', 'rb'),
                                                       emojis=sticker_emoji)

                    except Exception as e:                   
                        if str(e) == "Stickerset_invalid":                            
                            extra_version = ""
                            if packnum > 0:
                                extra_version = " " + str(packnum)
                            try:
                                context.bot.create_new_sticker_set(user.id, packname, f"{name}'s kang pack" + extra_version,
                                                               tgs_sticker=open(
                                                                   f'{idk}x/{k}.tgs', 'rb'),
                                                               emojis=sticker_emoji)
                            except Exception as e:
                                if str(e) == "Peer_id_invalid":
                                      context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text="Contact me in PM first.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                                                            text="Start", url=f"t.me/{context.bot.username}?start")]]))
                                      lgbt = True
                                      break
                                
                        elif str(e) == "Stickers_too_much" or e == "Stickerkang_stickers_too_much":
                            packnum += 1
                            extra_version = " " + str(packnum)
                            packname = "kang_" + \
                                 str(packnum) + "_" + str(user.id) + \
                                 "animated_by_"+str(context.bot.username)
                            try:
                                context.bot.create_new_sticker_set(user.id, packname, f"{name}'s kang pack" + extra_version,
                                                                   tgs_sticker=open(
                                                                       f'{idk}x/{k}.tgs', 'rb'),
                                                                   emojis=sticker_emoji)
                            except:
                                context.bot.add_sticker_to_set(user_id=user.id,
                                                               name=packname,
                                                               tgs_sticker=open(
                                                                   f'{idk}x/{k}.tgs', 'rb'),
                                                               emojis=sticker_emoji)
                        elif str(e) == "Peer_id_invalid":
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text="Contact me in PM first.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                                                            text="Start", url=f"t.me/{context.bot.username}?start")]]))
                            lgbt = True
                            break
                        else:
                            print("packkang error(animated)\n", e)
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text=f"Error !\nTry `/packkang {k}` to continue kang.")
                            lgbt = True
                            break

                k += 1

            if lgbt:
                return
            else:
                context.bot.editMessageText(chat_id=chat_id,
                                            message_id=one.message_id,
                                            parse_mode='markdown',
                                            text=f"Done !\nPack: [Sticker pack](t.me/addstickers/{packname}")
                                            
        elif msg.reply_to_message.sticker.is_video:
            mpackname = update.message.reply_to_message.sticker.set_name
            mstickerset = context.bot.get_sticker_set(mpackname).stickers
            sticker_num = len(mstickerset)
            k = 1
            lgbt = None
            packname = "kang_" + str(user_id) + \
                "video_by_"+str(context.bot.username)
            packname_found = 0
            max_stickers = 50
            packnum = 0
            fs = 1
            ts = sticker_num
            if " " in str(msg.text):
                wwe = str(msg.text).split()[1]

                if "-" in wwe:
                    try:
                        fs = int(wwe.split("-")[0])
                        if not fs < 120 and not fs > 0:
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text=f"Sike!, that's the wrong number!")
                            return
                        ts = int(wwe.split("-")[1])
                        if not ts <= 120:
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_m='markdown',
                                                        text=f"Sike!, that's the wrong number!")
                            return
                        if fs > ts:
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text=f"Wrong info !")
                            return
                    except:
                        context.bot.editMessageText(chat_id=chat_id,
                                                    message_id=one.message_id,
                                                    parse_mode='markdown',
                                                    text=f"Sike!, that's the wrong number!")
                        return
                elif wwe.isdigit():
                    try:
                        fs = int(wwe)
                        ts = sticker_num
                        if not fs >= ts and not fs > 0:
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text=f"Sike!, that's the wrong number!")
                            return
                    except:
                        context.bot.editMessageText(chat_id=chat_id,
                                                    message_id=one.message_id,
                                                    parse_mode='markdown',
                                                    text=f"Sike!, that's the wrong number!")
                        return
        ######
            packname_found = 0
            max_stickers = 50
            while packname_found == 0:
                try:
                    stickerset = context.bot.get_sticker_set(packname)
                    if len(stickerset.stickers) >= max_stickers:
                        packnum += 1
                        packname = "kang_" + \
                            str(packnum) + "_" + str(user.id) + \
                            "video_by_"+str(context.bot.username)
                    else:
                        packname_found = 1
                except Exception as e:
                    if str(e) == "Stickerset_invalid":
                        packname_found = 1
            for i in mstickerset:
                if k > ts:
                    break
                try:
                    sticker_emoji = i.emoji
                except:
                    sticker_emoji = random.choice(emojiss)
                if (fs > 1 and fs <= k) or (fs == 1):
                    try:
                        two = context.bot.editMessageText(chat_id=chat_id,
                                                          message_id=one.message_id,
                                                          parse_mode='markdown',
                                                          text=f"Kanging {k}/{sticker_num}\nWith emoji '{sticker_emoji}'")
                    except:
                        pass
                    kang_file = context.bot.get_file(i.file_id)
                    kang_file.download(f'{idk}x/{k}.webm')

                    try:
                        context.bot.add_sticker_to_set(user_id=user.id,
                                                       name=packname,
                                                       webm_sticker=open(
                                                           f'{idk}x/{k}.webm', 'rb'),
                                                       emojis=sticker_emoji)

                    except Exception as e:                   
                        if str(e) == "Stickerset_invalid":                            
                            extra_version = ""
                            if packnum > 0:
                                extra_version = " " + str(packnum)
                            try:
                                context.bot.create_new_sticker_set(user.id, packname, f"{name}'s kang pack" + extra_version,
                                                               webm_sticker=open(
                                                                   f'{idk}x/{k}.webm', 'rb'),
                                                               emojis=sticker_emoji)
                            except Exception as e:
                                if str(e) == "Peer_id_invalid":
                                      context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text="Contact me in PM first.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                                                            text="Start", url=f"t.me/{context.bot.username}?start")]]))
                                      lgbt = True
                                      break
                                
                        elif str(e) == "Stickers_too_much" or e == "Stickerkang_stickers_too_much":
                            packnum += 1
                            extra_version = " " + str(packnum)
                            packname = "kang_" + \
                                 str(packnum) + "_" + str(user.id) + \
                                 "video_by_"+str(context.bot.username)
                            try:
                                context.bot.create_new_sticker_set(user.id, packname, f"{name}'s kang pack" + extra_version,
                                                                   webm_sticker=open(
                                                                       f'{idk}x/{k}.webm', 'rb'),
                                                                   emojis=sticker_emoji)
                            except:
                                context.bot.add_sticker_to_set(user_id=user.id,
                                                               name=packname,
                                                               webm_sticker=open(
                                                                   f'{idk}x/{k}.webm', 'rb'),
                                                               emojis=sticker_emoji)
                        elif str(e) == "Peer_id_invalid":
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text="Contact me in PM first.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(
                                                            text="Start", url=f"t.me/{context.bot.username}?start")]]))
                            lgbt = True
                            break
                        else:
                            print("packkang error(video)\n", e)
                            context.bot.editMessageText(chat_id=chat_id,
                                                        message_id=one.message_id,
                                                        parse_mode='markdown',
                                                        text=f"Error !\nTry `/packkang {k}` to continue kang.")
                            lgbt = True
                            break

                k += 1

            if lgbt:
                return
            else:
                context.bot.editMessageText(chat_id=chat_id,
                                            message_id=one.message_id,
                                            parse_mode='markdown',
                                            text=f"Done !\nPack: [Sticker pack](t.me/addstickers/{packname}")
                                
        else:
            msg.reply_text("I can't kang that")
            return
       
        os.system(f"rm -rf {idk}x")        
    else:
        context.bot.editMessageText(chat_id=chat_id,
                                    message_id=one.message_id,
                                    parse_mode='markdown',
                                    text=f"Reply to sticker pack to kang them all.")



def filters(update, context):
     if update.message.text:
         print(update.message.from_user.id, update.message.text)
     elif update.message.sticker:
         print(update.message.from_user.id, update.message.sticker.file_id)



def setup_dispatcher(dp):
    dp.add_handler(CommandHandler('start', start, run_async=True))
    dp.add_handler(CommandHandler('restart', restart, run_async=True))
    dp.add_handler(CommandHandler('logs', logs, run_async=True))
    dp.add_handler(CommandHandler('kang', kang, run_async=True))
    dp.add_handler(CommandHandler('ping', ping, run_async=True))
    dp.add_handler(CommandHandler('delsticker', delsticker, run_async=True))
    dp.add_handler(CommandHandler('mypacks', mypacks, run_async=True))
    dp.add_handler(CommandHandler('nuke', nuke, run_async=True))
    dp.add_handler(CommandHandler(['packkang', 'pkang'], kangall))
    dp.add_handler(MessageHandler(Filters.chat_type.private, filters, run_async=True))
  

updater = Updater(TELEGRAM_TOKEN)
dp = updater.dispatcher
dp = setup_dispatcher(dp)


HEROKU_APP_NAME = os.getenv("HEROKU_APP_NAME", None)
PORT = int(os.environ.get('PORT', '8443'))


def main():
    if HEROKU_APP_NAME is None:  # pooling mode
        print("Can't detect 'HEROKU_APP_NAME' env. Running bot in pooling mode.")
        print("Note: this is not a great way to deploy the bot in Heroku.")
        print("Bot has been started !")
        updater.start_polling()
        updater.idle()

    else:  # webhook mode
        print(
            f"Running bot in webhook mode. Make sure that this url is correct: https://{HEROKU_APP_NAME}.herokuapp.com/")
        updater.start_webhook(
            listen="0.0.0.0",
            port=PORT,
            url_path=TELEGRAM_TOKEN,
            webhook_url=f"https://{HEROKU_APP_NAME}.herokuapp.com/{TELEGRAM_TOKEN}"
        )


if __name__ == "__main__":
    main()

