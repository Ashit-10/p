from moviepy.editor import VideoFileClip as vfclip


def sendinfo(vid):

     clip = vfclip(str(vid)) 
     clip1 = clip.subclip(0, 10)
     print(clip.duration)
     a = clip1.w
     b = clip1.h
     c = clip.duration - 0.2
     print(a, b ,c)
     
     return a, b, c
